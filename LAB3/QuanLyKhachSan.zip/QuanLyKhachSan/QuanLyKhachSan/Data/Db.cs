﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyKhachSan.Data
{
    public static class Db
    {
        // Lấy chuỗi kết nối từ file App.config
        public static string ConnectionString
        {
            get
            {
                var settings = ConfigurationManager.ConnectionStrings["QuanLyKhachSan"];
                if (settings == null)
                {
                    throw new Exception("Không tìm thấy chuỗi kết nối 'QuanLyKhachSan' trong file App.config!\nHãy kiểm tra lại file App.config.");
                }
                return settings.ConnectionString;
            }
        }

        // Mở kết nối đến SQL Server
        public static SqlConnection OpenConnection()
        {
            try
            {
                SqlConnection cn = new SqlConnection(ConnectionString);
                cn.Open();
                return cn;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối CSDL SQL Server:\n" + ex.Message, "Lỗi Kết Nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
        }

        // Thực thi truy vấn SELECT
        public static DataTable Query(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddRange(parameters);
                }

                DataTable table = new DataTable();
                da.Fill(table);
                return table;
            }
        }

        // Thực thi câu lệnh INSERT, UPDATE, DELETE
        public static int Execute(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddRange(parameters);
                }

                return cmd.ExecuteNonQuery();
            }
        }

        // Thực thi câu lệnh trả về 1 giá trị duy nhất (COUNT, MAX, SUM,...)
        public static object Scalar(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddRange(parameters);
                }

                return cmd.ExecuteScalar();
            }
        }
    }
}