﻿namespace QuanLyKhachSan
{
    partial class FrmDichVu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblPhieuLuuTru = new System.Windows.Forms.Label();
            this.txtPhieuLuuTru = new System.Windows.Forms.TextBox();

            this.lblPhong = new System.Windows.Forms.Label();
            this.txtPhong = new System.Windows.Forms.TextBox();

            this.lblDichVu = new System.Windows.Forms.Label();
            this.txtDichVu = new System.Windows.Forms.TextBox();

            this.lblNgaySuDung = new System.Windows.Forms.Label();
            this.dtNgaySuDung = new System.Windows.Forms.DateTimePicker();

            this.lblSoLuong = new System.Windows.Forms.Label();
            this.txtSoLuong = new System.Windows.Forms.TextBox();

            this.btnGhiNhan = new System.Windows.Forms.Button();

            this.dgvDichVu = new System.Windows.Forms.DataGridView();

            ((System.ComponentModel.ISupportInitialize)(this.dgvDichVu)).BeginInit();
            this.SuspendLayout();

            // 
            // lblPhieuLuuTru
            // 
            this.lblPhieuLuuTru.AutoSize = true;
            this.lblPhieuLuuTru.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.lblPhieuLuuTru.Location = new System.Drawing.Point(30, 32);
            this.lblPhieuLuuTru.Name = "lblPhieuLuuTru";
            this.lblPhieuLuuTru.Size = new System.Drawing.Size(106, 23);
            this.lblPhieuLuuTru.TabIndex = 0;
            this.lblPhieuLuuTru.Text = "Phiếu lưu trú:";

            // 
            // txtPhieuLuuTru
            // 
            this.txtPhieuLuuTru.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.txtPhieuLuuTru.Location = new System.Drawing.Point(145, 28);
            this.txtPhieuLuuTru.Name = "txtPhieuLuuTru";
            this.txtPhieuLuuTru.Size = new System.Drawing.Size(170, 30);
            this.txtPhieuLuuTru.TabIndex = 1;

            // 
            // lblPhong
            // 
            this.lblPhong.AutoSize = true;
            this.lblPhong.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.lblPhong.Location = new System.Drawing.Point(345, 32);
            this.lblPhong.Name = "lblPhong";
            this.lblPhong.Size = new System.Drawing.Size(60, 23);
            this.lblPhong.TabIndex = 2;
            this.lblPhong.Text = "Phòng:";

            // 
            // txtPhong
            // 
            this.txtPhong.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.txtPhong.Location = new System.Drawing.Point(415, 28);
            this.txtPhong.Name = "txtPhong";
            this.txtPhong.Size = new System.Drawing.Size(120, 30);
            this.txtPhong.TabIndex = 3;

            // 
            // lblDichVu
            // 
            this.lblDichVu.AutoSize = true;
            this.lblDichVu.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.lblDichVu.Location = new System.Drawing.Point(560, 32);
            this.lblDichVu.Name = "lblDichVu";
            this.lblDichVu.Size = new System.Drawing.Size(72, 23);
            this.lblDichVu.TabIndex = 4;
            this.lblDichVu.Text = "Dịch vụ:";

            // 
            // txtDichVu
            // 
            this.txtDichVu.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.txtDichVu.Location = new System.Drawing.Point(640, 28);
            this.txtDichVu.Name = "txtDichVu";
            this.txtDichVu.Size = new System.Drawing.Size(210, 30);
            this.txtDichVu.TabIndex = 5;

            // 
            // lblNgaySuDung
            // 
            this.lblNgaySuDung.AutoSize = true;
            this.lblNgaySuDung.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.lblNgaySuDung.Location = new System.Drawing.Point(30, 88);
            this.lblNgaySuDung.Name = "lblNgaySuDung";
            this.lblNgaySuDung.Size = new System.Drawing.Size(117, 23);
            this.lblNgaySuDung.TabIndex = 6;
            this.lblNgaySuDung.Text = "Ngày sử dụng:";

            // 
            // dtNgaySuDung
            // 
            this.dtNgaySuDung.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.dtNgaySuDung.Format =
                System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNgaySuDung.Location =
                new System.Drawing.Point(155, 84);
            this.dtNgaySuDung.Name = "dtNgaySuDung";
            this.dtNgaySuDung.Size = new System.Drawing.Size(170, 30);
            this.dtNgaySuDung.TabIndex = 7;

            // 
            // lblSoLuong
            // 
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.lblSoLuong.Location = new System.Drawing.Point(345, 88);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(79, 23);
            this.lblSoLuong.TabIndex = 8;
            this.lblSoLuong.Text = "Số lượng:";

            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.txtSoLuong.Location =
                new System.Drawing.Point(435, 84);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(120, 30);
            this.txtSoLuong.TabIndex = 9;
            this.txtSoLuong.Text = "1";

            // 
            // btnGhiNhan
            // 
            this.btnGhiNhan.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.btnGhiNhan.Location =
                new System.Drawing.Point(640, 78);
            this.btnGhiNhan.Name = "btnGhiNhan";
            this.btnGhiNhan.Size = new System.Drawing.Size(170, 42);
            this.btnGhiNhan.TabIndex = 10;
            this.btnGhiNhan.Text = "Ghi nhận";
            this.btnGhiNhan.UseVisualStyleBackColor = true;
            this.btnGhiNhan.Click +=
                new System.EventHandler(this.btnGhiNhan_Click);

            // 
            // dgvDichVu
            // 
            this.dgvDichVu.AllowUserToAddRows = false;
            this.dgvDichVu.AllowUserToDeleteRows = false;
            this.dgvDichVu.AutoSizeColumnsMode =
                System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDichVu.BackgroundColor =
                System.Drawing.SystemColors.Window;
            this.dgvDichVu.ColumnHeadersHeight = 35;
            this.dgvDichVu.Location =
                new System.Drawing.Point(30, 145);
            this.dgvDichVu.MultiSelect = false;
            this.dgvDichVu.Name = "dgvDichVu";
            this.dgvDichVu.ReadOnly = true;
            this.dgvDichVu.RowHeadersWidth = 40;
            this.dgvDichVu.RowTemplate.Height = 38;
            this.dgvDichVu.SelectionMode =
                System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDichVu.Size =
                new System.Drawing.Size(820, 390);
            this.dgvDichVu.TabIndex = 11;

            // 
            // FrmDichVu
            // 
            this.AutoScaleDimensions =
                new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize =
                new System.Drawing.Size(890, 570);
            this.Controls.Add(this.dgvDichVu);
            this.Controls.Add(this.btnGhiNhan);
            this.Controls.Add(this.txtSoLuong);
            this.Controls.Add(this.lblSoLuong);
            this.Controls.Add(this.dtNgaySuDung);
            this.Controls.Add(this.lblNgaySuDung);
            this.Controls.Add(this.txtDichVu);
            this.Controls.Add(this.lblDichVu);
            this.Controls.Add(this.txtPhong);
            this.Controls.Add(this.lblPhong);
            this.Controls.Add(this.txtPhieuLuuTru);
            this.Controls.Add(this.lblPhieuLuuTru);
            this.Font = new System.Drawing.Font(
                "Segoe UI", 10F);
            this.FormBorderStyle =
                System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmDichVu";
            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sử dụng dịch vụ";
            ((System.ComponentModel.ISupportInitialize)(this.dgvDichVu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblPhieuLuuTru;
        private System.Windows.Forms.TextBox txtPhieuLuuTru;

        private System.Windows.Forms.Label lblPhong;
        private System.Windows.Forms.TextBox txtPhong;

        private System.Windows.Forms.Label lblDichVu;
        private System.Windows.Forms.TextBox txtDichVu;

        private System.Windows.Forms.Label lblNgaySuDung;
        private System.Windows.Forms.DateTimePicker dtNgaySuDung;

        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.TextBox txtSoLuong;

        private System.Windows.Forms.Button btnGhiNhan;

        private System.Windows.Forms.DataGridView dgvDichVu;
    }
}
