﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan
{
    public partial class FrmDichVu : Form
    {
        public FrmDichVu()
        {
            InitializeComponent();

            dtNgaySuDung.Format = DateTimePickerFormat.Short;

            Load += FrmDichVu_Load;
            btnGhiNhan.Click += btnGhiNhan_Click;
            dgvDichVu.CellClick += dgvDichVu_CellClick;
        }

        private void FrmDichVu_Load(object sender, EventArgs e)
        {
            LoadDichVu();
        }

        private void LoadDichVu()
        {
            try
            {
                string sql = @"
                    SELECT
                        dv.MaDV AS MaDichVu,
                        dv.TenDV AS DichVu,
                        dv.DonViTinh AS DonVi,
                        dv.DonGia
                    FROM DichVu dv
                    ORDER BY dv.MaDV";

                dgvDichVu.DataSource = Db.Query(sql);

                DinhDangGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không tải được danh sách dịch vụ:\n\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void DinhDangGrid()
        {
            if (dgvDichVu.Columns.Count == 0)
                return;

            if (dgvDichVu.Columns.Contains("MaDichVu"))
                dgvDichVu.Columns["MaDichVu"].HeaderText = "Mã dịch vụ";

            if (dgvDichVu.Columns.Contains("DichVu"))
                dgvDichVu.Columns["DichVu"].HeaderText = "Dịch vụ";

            if (dgvDichVu.Columns.Contains("DonVi"))
                dgvDichVu.Columns["DonVi"].HeaderText = "Đơn vị";

            if (dgvDichVu.Columns.Contains("DonGia"))
            {
                dgvDichVu.Columns["DonGia"].HeaderText = "Đơn giá";
                dgvDichVu.Columns["DonGia"].DefaultCellStyle.Format = "N0";
            }

            dgvDichVu.ReadOnly = true;
            dgvDichVu.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvDichVu.MultiSelect = false;
            dgvDichVu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void dgvDichVu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row = dgvDichVu.Rows[e.RowIndex];

            if (row.Cells["DichVu"].Value != null)
            {
                txtDichVu.Text = row.Cells["DichVu"].Value.ToString();
            }
        }

        private void btnGhiNhan_Click(object sender, EventArgs e)
        {
            string soPhieuDat = txtPhieuLuuTru.Text.Trim();
            string soPhong = txtPhong.Text.Trim();
            string tenDichVu = txtDichVu.Text.Trim();

            if (string.IsNullOrWhiteSpace(soPhieuDat))
            {
                MessageBox.Show(
                    "Vui lòng nhập phiếu lưu trú.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                txtPhieuLuuTru.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(soPhong))
            {
                MessageBox.Show(
                    "Vui lòng nhập phòng.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                txtPhong.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(tenDichVu))
            {
                MessageBox.Show(
                    "Vui lòng nhập tên dịch vụ.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                txtDichVu.Focus();
                return;
            }

            if (!int.TryParse(txtSoLuong.Text.Trim(), out int soLuong) || soLuong <= 0)
            {
                MessageBox.Show(
                    "Số lượng phải là số nguyên lớn hơn 0.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                txtSoLuong.Focus();
                return;
            }

            try
            {
                // 1. Kiểm tra phiếu đặt + phòng
                string sqlKiemTra = @"
                    SELECT COUNT(*)
                    FROM ChiTietDatPhong
                    WHERE SoPhieuDat = @SoPhieuDat
                      AND SoPhong = @SoPhong";

                int tonTai = Convert.ToInt32(
                    Db.Scalar(sqlKiemTra,
                        new SqlParameter("@SoPhieuDat", soPhieuDat),
                        new SqlParameter("@SoPhong", soPhong)
                    )
                );

                if (tonTai == 0)
                {
                    MessageBox.Show(
                        "Không tìm thấy phòng này trong phiếu đặt.",
                        "Thông báo",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                // 2. Tìm mã dịch vụ và đơn giá theo tên
                string sqlDV = @"
                    SELECT MaDV, DonGia
                    FROM DichVu
                    WHERE TenDV = @TenDV";

                DataTable dtDV = Db.Query(sqlDV, new SqlParameter("@TenDV", tenDichVu));

                if (dtDV.Rows.Count == 0)
                {
                    MessageBox.Show(
                        "Không tìm thấy dịch vụ: " + tenDichVu,
                        "Thông báo",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                string maDV = dtDV.Rows[0]["MaDV"].ToString();
                decimal donGia = Convert.ToDecimal(dtDV.Rows[0]["DonGia"]);

                // 3. Tạo mã phiếu sử dụng dịch vụ
                string soPhieuSDDV = "SD" + DateTime.Now.ToString("yyyyMMddHHmmssfff");

                // 4. Thêm phiếu sử dụng dịch vụ
                string sqlPhieu = @"
                    INSERT INTO PhieuSuDungDV
                    (
                        SoPhieuSDDV,
                        SoPhieuDat,
                        SoPhong,
                        NgaySuDung,
                        MaNV
                    )
                    VALUES
                    (
                        @SoPhieuSDDV,
                        @SoPhieuDat,
                        @SoPhong,
                        @NgaySuDung,
                        @MaNV
                    )";

                Db.Execute(sqlPhieu,
                    new SqlParameter("@SoPhieuSDDV", soPhieuSDDV),
                    new SqlParameter("@SoPhieuDat", soPhieuDat),
                    new SqlParameter("@SoPhong", soPhong),
                    new SqlParameter("@NgaySuDung", dtNgaySuDung.Value.Date),
                    new SqlParameter("@MaNV", "NV01")
                );

                // 5. Thêm chi tiết dịch vụ
                string sqlChiTiet = @"
                    INSERT INTO ChiTietPhieuSuDungDV
                    (
                        SoPhieuSDDV,
                        MaDV,
                        SoLuong,
                        DonGia
                    )
                    VALUES
                    (
                        @SoPhieuSDDV,
                        @MaDV,
                        @SoLuong,
                        @DonGia
                    )";

                Db.Execute(sqlChiTiet,
                    new SqlParameter("@SoPhieuSDDV", soPhieuSDDV),
                    new SqlParameter("@MaDV", maDV),
                    new SqlParameter("@SoLuong", soLuong),
                    new SqlParameter("@DonGia", donGia)
                );

                MessageBox.Show(
                    "Ghi nhận sử dụng dịch vụ thành công!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LoadDichVu();
                XoaNhapLieu();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể ghi nhận dịch vụ:\n\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void XoaNhapLieu()
        {
            txtPhieuLuuTru.Clear();
            txtPhong.Clear();
            txtDichVu.Clear();
            txtSoLuong.Text = "1";
            dtNgaySuDung.Value = DateTime.Now;
        }
    }
}