﻿namespace QuanLyKhachSan
{
    partial class FrmTraPhong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPhieuDangO = new System.Windows.Forms.Label();
            this.txtPhieuDangO = new System.Windows.Forms.TextBox();
            this.dgvPhong = new System.Windows.Forms.DataGridView();
            this.dgvTienNghiDenBu = new System.Windows.Forms.DataGridView();
            this.lblSoPhieuDenBu = new System.Windows.Forms.Label();
            this.txtSoPhieuDenBu = new System.Windows.Forms.TextBox();
            this.lblMucDo = new System.Windows.Forms.Label();
            this.cboMucDo = new System.Windows.Forms.ComboBox();
            this.lblSoTienDenBu = new System.Windows.Forms.Label();
            this.txtSoTienDenBu = new System.Windows.Forms.TextBox();
            this.btnLapPhieuDenBu = new System.Windows.Forms.Button();
            this.lblSoHoaDon = new System.Windows.Forms.Label();
            this.txtSoHoaDon = new System.Windows.Forms.TextBox();
            this.lblSoNgayTinhTien = new System.Windows.Forms.Label();
            this.txtSoNgayTinhTien = new System.Windows.Forms.TextBox();
            this.btnLapHoaDon = new System.Windows.Forms.Button();
            this.dgvHoaDon = new System.Windows.Forms.DataGridView();
            this.lblHinhThuc = new System.Windows.Forms.Label();
            this.cboHinhThuc = new System.Windows.Forms.ComboBox();
            this.lblSoTienThanhToan = new System.Windows.Forms.Label();
            this.txtSoTienThanhToan = new System.Windows.Forms.TextBox();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnHoanTatTraPhong = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienNghiDenBu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).BeginInit();
            this.SuspendLayout();

            // lblPhieuDangO
            this.lblPhieuDangO.AutoSize = true;
            this.lblPhieuDangO.Location = new System.Drawing.Point(30, 20);
            this.lblPhieuDangO.Name = "lblPhieuDangO";
            this.lblPhieuDangO.Size = new System.Drawing.Size(95, 16);
            this.lblPhieuDangO.Text = "Phiếu đang ở:";

            // txtPhieuDangO
            this.txtPhieuDangO.Location = new System.Drawing.Point(135, 17);
            this.txtPhieuDangO.Name = "txtPhieuDangO";
            this.txtPhieuDangO.Size = new System.Drawing.Size(150, 22);

            // dgvPhong
            this.dgvPhong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhong.Location = new System.Drawing.Point(30, 50);
            this.dgvPhong.Name = "dgvPhong";
            this.dgvPhong.RowHeadersWidth = 51;
            this.dgvPhong.Size = new System.Drawing.Size(430, 160);

            // dgvTienNghiDenBu
            this.dgvTienNghiDenBu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTienNghiDenBu.Location = new System.Drawing.Point(475, 50);
            this.dgvTienNghiDenBu.Name = "dgvTienNghiDenBu";
            this.dgvTienNghiDenBu.RowHeadersWidth = 51;
            this.dgvTienNghiDenBu.Size = new System.Drawing.Size(320, 160);

            // lblSoPhieuDenBu
            this.lblSoPhieuDenBu.AutoSize = true;
            this.lblSoPhieuDenBu.Location = new System.Drawing.Point(30, 225);
            this.lblSoPhieuDenBu.Name = "lblSoPhieuDenBu";
            this.lblSoPhieuDenBu.Size = new System.Drawing.Size(109, 16);
            this.lblSoPhieuDenBu.Text = "Số phiếu đền bù:";

            // txtSoPhieuDenBu
            this.txtSoPhieuDenBu.Location = new System.Drawing.Point(145, 222);
            this.txtSoPhieuDenBu.Name = "txtSoPhieuDenBu";
            this.txtSoPhieuDenBu.Size = new System.Drawing.Size(120, 22);

            // lblMucDo
            this.lblMucDo.AutoSize = true;
            this.lblMucDo.Location = new System.Drawing.Point(280, 225);
            this.lblMucDo.Name = "lblMucDo";
            this.lblMucDo.Size = new System.Drawing.Size(54, 16);
            this.lblMucDo.Text = "Mức độ:";

            // cboMucDo
            this.cboMucDo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMucDo.FormattingEnabled = true;
            this.cboMucDo.Location = new System.Drawing.Point(340, 222);
            this.cboMucDo.Name = "cboMucDo";
            this.cboMucDo.Size = new System.Drawing.Size(120, 24);

            // lblSoTienDenBu
            this.lblSoTienDenBu.AutoSize = true;
            this.lblSoTienDenBu.Location = new System.Drawing.Point(475, 225);
            this.lblSoTienDenBu.Name = "lblSoTienDenBu";
            this.lblSoTienDenBu.Size = new System.Drawing.Size(51, 16);
            this.lblSoTienDenBu.Text = "Số tiền:";

            // txtSoTienDenBu
            this.txtSoTienDenBu.Location = new System.Drawing.Point(535, 222);
            this.txtSoTienDenBu.Name = "txtSoTienDenBu";
            this.txtSoTienDenBu.Size = new System.Drawing.Size(110, 22);

            // btnLapPhieuDenBu
            this.btnLapPhieuDenBu.Location = new System.Drawing.Point(655, 220);
            this.btnLapPhieuDenBu.Name = "btnLapPhieuDenBu";
            this.btnLapPhieuDenBu.Size = new System.Drawing.Size(140, 26);
            this.btnLapPhieuDenBu.Text = "Lập phiếu đền bù";
            this.btnLapPhieuDenBu.UseVisualStyleBackColor = true;

            // lblSoHoaDon
            this.lblSoHoaDon.AutoSize = true;
            this.lblSoHoaDon.Location = new System.Drawing.Point(30, 265);
            this.lblSoHoaDon.Name = "lblSoHoaDon";
            this.lblSoHoaDon.Size = new System.Drawing.Size(79, 16);
            this.lblSoHoaDon.Text = "Số hóa đơn:";

            // txtSoHoaDon
            this.txtSoHoaDon.Location = new System.Drawing.Point(115, 262);
            this.txtSoHoaDon.Name = "txtSoHoaDon";
            this.txtSoHoaDon.Size = new System.Drawing.Size(120, 22);

            // lblSoNgayTinhTien
            this.lblSoNgayTinhTien.AutoSize = true;
            this.lblSoNgayTinhTien.Location = new System.Drawing.Point(250, 265);
            this.lblSoNgayTinhTien.Name = "lblSoNgayTinhTien";
            this.lblSoNgayTinhTien.Size = new System.Drawing.Size(112, 16);
            this.lblSoNgayTinhTien.Text = "Số ngày tính tiền:";

            // txtSoNgayTinhTien
            this.txtSoNgayTinhTien.Location = new System.Drawing.Point(368, 262);
            this.txtSoNgayTinhTien.Name = "txtSoNgayTinhTien";
            this.txtSoNgayTinhTien.Size = new System.Drawing.Size(70, 22);

            // btnLapHoaDon
            this.btnLapHoaDon.Location = new System.Drawing.Point(475, 260);
            this.btnLapHoaDon.Name = "btnLapHoaDon";
            this.btnLapHoaDon.Size = new System.Drawing.Size(120, 26);
            this.btnLapHoaDon.Text = "Lập hóa đơn";
            this.btnLapHoaDon.UseVisualStyleBackColor = true;

            // dgvHoaDon
            this.dgvHoaDon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoaDon.Location = new System.Drawing.Point(30, 298);
            this.dgvHoaDon.Name = "dgvHoaDon";
            this.dgvHoaDon.RowHeadersWidth = 51;
            this.dgvHoaDon.Size = new System.Drawing.Size(765, 160);

            // lblHinhThuc
            this.lblHinhThuc.AutoSize = true;
            this.lblHinhThuc.Location = new System.Drawing.Point(30, 475);
            this.lblHinhThuc.Name = "lblHinhThuc";
            this.lblHinhThuc.Size = new System.Drawing.Size(65, 16);
            this.lblHinhThuc.Text = "Hình thức:";

            // cboHinhThuc
            this.cboHinhThuc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHinhThuc.FormattingEnabled = true;
            this.cboHinhThuc.Location = new System.Drawing.Point(105, 472);
            this.cboHinhThuc.Name = "cboHinhThuc";
            this.cboHinhThuc.Size = new System.Drawing.Size(130, 24);

            // lblSoTienThanhToan
            this.lblSoTienThanhToan.AutoSize = true;
            this.lblSoTienThanhToan.Location = new System.Drawing.Point(255, 475);
            this.lblSoTienThanhToan.Name = "lblSoTienThanhToan";
            this.lblSoTienThanhToan.Size = new System.Drawing.Size(51, 16);
            this.lblSoTienThanhToan.Text = "Số tiền:";

            // txtSoTienThanhToan
            this.txtSoTienThanhToan.Location = new System.Drawing.Point(315, 472);
            this.txtSoTienThanhToan.Name = "txtSoTienThanhToan";
            this.txtSoTienThanhToan.Size = new System.Drawing.Size(120, 22);

            // btnThanhToan
            this.btnThanhToan.Location = new System.Drawing.Point(475, 470);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(120, 28);
            this.btnThanhToan.Text = "Thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;

            // btnHoanTatTraPhong
            this.btnHoanTatTraPhong.Location = new System.Drawing.Point(615, 470);
            this.btnHoanTatTraPhong.Name = "btnHoanTatTraPhong";
            this.btnHoanTatTraPhong.Size = new System.Drawing.Size(180, 28);
            this.btnHoanTatTraPhong.Text = "Hoàn tất trả phòng";
            this.btnHoanTatTraPhong.UseVisualStyleBackColor = true;

            // FrmTraPhong
            this.ClientSize = new System.Drawing.Size(825, 520);
            this.Controls.Add(this.btnHoanTatTraPhong);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.txtSoTienThanhToan);
            this.Controls.Add(this.lblSoTienThanhToan);
            this.Controls.Add(this.cboHinhThuc);
            this.Controls.Add(this.lblHinhThuc);
            this.Controls.Add(this.dgvHoaDon);
            this.Controls.Add(this.btnLapHoaDon);
            this.Controls.Add(this.txtSoNgayTinhTien);
            this.Controls.Add(this.lblSoNgayTinhTien);
            this.Controls.Add(this.txtSoHoaDon);
            this.Controls.Add(this.lblSoHoaDon);
            this.Controls.Add(this.btnLapPhieuDenBu);
            this.Controls.Add(this.txtSoTienDenBu);
            this.Controls.Add(this.lblSoTienDenBu);
            this.Controls.Add(this.cboMucDo);
            this.Controls.Add(this.lblMucDo);
            this.Controls.Add(this.txtSoPhieuDenBu);
            this.Controls.Add(this.lblSoPhieuDenBu);
            this.Controls.Add(this.dgvTienNghiDenBu);
            this.Controls.Add(this.dgvPhong);
            this.Controls.Add(this.txtPhieuDangO);
            this.Controls.Add(this.lblPhieuDangO);
            this.Name = "FrmTraPhong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trả phòng - Đền bù - Hóa đơn - Thanh toán";
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienNghiDenBu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblPhieuDangO;
        private System.Windows.Forms.TextBox txtPhieuDangO;
        private System.Windows.Forms.DataGridView dgvPhong;
        private System.Windows.Forms.DataGridView dgvTienNghiDenBu;
        private System.Windows.Forms.Label lblSoPhieuDenBu;
        private System.Windows.Forms.TextBox txtSoPhieuDenBu;
        private System.Windows.Forms.Label lblMucDo;
        private System.Windows.Forms.ComboBox cboMucDo;
        private System.Windows.Forms.Label lblSoTienDenBu;
        private System.Windows.Forms.TextBox txtSoTienDenBu;
        private System.Windows.Forms.Button btnLapPhieuDenBu;
        private System.Windows.Forms.Label lblSoHoaDon;
        private System.Windows.Forms.TextBox txtSoHoaDon;
        private System.Windows.Forms.Label lblSoNgayTinhTien;
        private System.Windows.Forms.TextBox txtSoNgayTinhTien;
        private System.Windows.Forms.Button btnLapHoaDon;
        private System.Windows.Forms.DataGridView dgvHoaDon;
        private System.Windows.Forms.Label lblHinhThuc;
        private System.Windows.Forms.ComboBox cboHinhThuc;
        private System.Windows.Forms.Label lblSoTienThanhToan;
        private System.Windows.Forms.TextBox txtSoTienThanhToan;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnHoanTatTraPhong;
    }
}