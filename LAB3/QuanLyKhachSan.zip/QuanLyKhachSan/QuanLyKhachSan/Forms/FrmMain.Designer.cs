﻿namespace QuanLyKhachSan
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnDanhMuc;
        private System.Windows.Forms.Button btnPhongTienNghi;
        private System.Windows.Forms.Button btnDatNhanPhong;
        private System.Windows.Forms.Button btnDichVu;
        private System.Windows.Forms.Button btnTraPhongThanhToan;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.Button btnThoat;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnDanhMuc = new System.Windows.Forms.Button();
            this.btnPhongTienNghi = new System.Windows.Forms.Button();
            this.btnDatNhanPhong = new System.Windows.Forms.Button();
            this.btnDichVu = new System.Windows.Forms.Button();
            this.btnTraPhongThanhToan = new System.Windows.Forms.Button();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(78)))), ((int)(((byte)(121)))));
            this.lblTitle.Location = new System.Drawing.Point(50, 25);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(800, 55);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "HỆ THỐNG QUẢN LÝ KHÁCH SẠN";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDanhMuc
            // 
            this.btnDanhMuc.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnDanhMuc.Location = new System.Drawing.Point(70, 120);
            this.btnDanhMuc.Name = "btnDanhMuc";
            this.btnDanhMuc.Size = new System.Drawing.Size(250, 75);
            this.btnDanhMuc.TabIndex = 1;
            this.btnDanhMuc.Text = "Danh mục";
            this.btnDanhMuc.UseVisualStyleBackColor = true;
            this.btnDanhMuc.Click += new System.EventHandler(this.btnDanhMuc_Click);
            // 
            // btnPhongTienNghi
            // 
            this.btnPhongTienNghi.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPhongTienNghi.Location = new System.Drawing.Point(330, 120);
            this.btnPhongTienNghi.Name = "btnPhongTienNghi";
            this.btnPhongTienNghi.Size = new System.Drawing.Size(250, 75);
            this.btnPhongTienNghi.TabIndex = 2;
            this.btnPhongTienNghi.Text = "Phòng - Tiện nghi";
            this.btnPhongTienNghi.UseVisualStyleBackColor = true;
            this.btnPhongTienNghi.Click += new System.EventHandler(this.btnPhongTienNghi_Click);
            // 
            // btnDatNhanPhong
            // 
            this.btnDatNhanPhong.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnDatNhanPhong.Location = new System.Drawing.Point(590, 120);
            this.btnDatNhanPhong.Name = "btnDatNhanPhong";
            this.btnDatNhanPhong.Size = new System.Drawing.Size(250, 75);
            this.btnDatNhanPhong.TabIndex = 3;
            this.btnDatNhanPhong.Text = "Đặt / Nhận phòng";
            this.btnDatNhanPhong.UseVisualStyleBackColor = true;
            this.btnDatNhanPhong.Click += new System.EventHandler(this.btnDatNhanPhong_Click);
            // 
            // btnDichVu
            // 
            this.btnDichVu.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnDichVu.Location = new System.Drawing.Point(70, 215);
            this.btnDichVu.Name = "btnDichVu";
            this.btnDichVu.Size = new System.Drawing.Size(250, 75);
            this.btnDichVu.TabIndex = 4;
            this.btnDichVu.Text = "Sử dụng dịch vụ";
            this.btnDichVu.UseVisualStyleBackColor = true;
            this.btnDichVu.Click += new System.EventHandler(this.btnDichVu_Click);
            // 
            // btnTraPhongThanhToan
            // 
            this.btnTraPhongThanhToan.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnTraPhongThanhToan.Location = new System.Drawing.Point(330, 215);
            this.btnTraPhongThanhToan.Name = "btnTraPhongThanhToan";
            this.btnTraPhongThanhToan.Size = new System.Drawing.Size(250, 75);
            this.btnTraPhongThanhToan.TabIndex = 5;
            this.btnTraPhongThanhToan.Text = "Trả phòng - Thanh toán";
            this.btnTraPhongThanhToan.UseVisualStyleBackColor = true;
            this.btnTraPhongThanhToan.Click += new System.EventHandler(this.btnTraPhongThanhToan_Click);
            // 
            // btnThongKe
            // 
            this.btnThongKe.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnThongKe.Location = new System.Drawing.Point(590, 215);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(250, 75);
            this.btnThongKe.TabIndex = 6;
            this.btnThongKe.Text = "Thống kê";
            this.btnThongKe.UseVisualStyleBackColor = true;
            this.btnThongKe.Click += new System.EventHandler(this.btnThongKe_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnThoat.Location = new System.Drawing.Point(330, 330);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(250, 75);
            this.btnThoat.TabIndex = 7;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 470);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnThongKe);
            this.Controls.Add(this.btnTraPhongThanhToan);
            this.Controls.Add(this.btnDichVu);
            this.Controls.Add(this.btnDatNhanPhong);
            this.Controls.Add(this.btnPhongTienNghi);
            this.Controls.Add(this.btnDanhMuc);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý khách sạn";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.ResumeLayout(false);

        }

        #endregion
    }
}