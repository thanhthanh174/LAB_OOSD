﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan
{
    public partial class FrmTraPhong : Form
    {
        // Mã nhân viên thao tác mặc định
        private string maNVHienTai = "NV01";

        public FrmTraPhong()
        {
            InitializeComponent();

            Load += FrmTraPhong_Load;

            txtPhieuDangO.KeyDown += txtPhieuDangO_KeyDown;
            dgvPhong.CellClick += dgvPhong_CellClick;

            btnLapPhieuDenBu.Click += btnLapPhieuDenBu_Click;
            btnLapHoaDon.Click += btnLapHoaDon_Click;
            btnThanhToan.Click += btnThanhToan_Click;
            btnHoanTatTraPhong.Click += btnHoanTatTraPhong_Click;
        }

        private void FrmTraPhong_Load(object sender, EventArgs e)
        {
            // Nạp dữ liệu vào Combobox Mức độ
            cboMucDo.Items.Clear();
            cboMucDo.Items.AddRange(new string[] {
                "Mất hoặc hỏng điều khiển Remote",
                "Vỡ màn hình / Hỏng hoàn toàn",
                "Móp méo / Hỏng lốc máy",
                "Hỏng điều khiển máy lạnh",
                "Mất chìa khóa / Quên mã đổi két"
            });
            if (cboMucDo.Items.Count > 0) cboMucDo.SelectedIndex = 0;

            // Nạp Combobox Hình thức thanh toán
            cboHinhThuc.Items.Clear();
            cboHinhThuc.Items.AddRange(new string[] { "Tiền mặt", "Thẻ", "Chuyển khoản", "Ví điện tử" });
            if (cboHinhThuc.Items.Count > 0) cboHinhThuc.SelectedIndex = 1;

            TaoMaTuDong();
            TaiTatCaPhongDangO();
        }

        private void TaoMaTuDong()
        {
            txtSoPhieuDenBu.Text = "PDB-" + DateTime.Now.ToString("ddHHmmss");
            txtSoHoaDon.Text = "HD-" + DateTime.Now.ToString("ddHHmmss");
            txtSoNgayTinhTien.Text = "1";
        }

        // Tải danh sách tất cả các phòng đang ở lên DataGridView Phòng
        private void TaiTatCaPhongDangO()
        {
            try
            {
                string sql = @"
                    SELECT 
                        ct.SoPhieuDat AS [Phiếu đặt],
                        ct.SoPhong AS [Phòng],
                        p.DonGiaNgay AS [Đơn giá/ngày],
                        ltn.TenLoaiTN AS [Tiện nghi],
                        p.MaKhuVuc AS [Loại],
                        p.TrangThai AS [Tình trạng]
                    FROM ChiTietDatPhong ct
                    INNER JOIN Phong p ON ct.SoPhong = p.SoPhong
                    INNER JOIN PhieuDatPhong pd ON ct.SoPhieuDat = pd.SoPhieuDat
                    LEFT JOIN PhieuLapDat pld ON p.SoPhong = pld.SoPhong
                    LEFT JOIN TienNghi tn ON pld.MaTienNghi = tn.MaTienNghi
                    LEFT JOIN LoaiTienNghi ltn ON tn.MaLoaiTN = ltn.MaLoaiTN
                    WHERE pd.TrangThai = N'Đang ở' OR p.TrangThai = N'Đang ở'";

                DataTable dt = Db.Query(sql);
                dgvPhong.DataSource = dt;
                dgvPhong.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvPhong.ReadOnly = true;
                dgvPhong.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nạp danh sách phòng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Khi bấm chọn một dòng phòng trong DataGridView -> Điền mã phiếu đặt & Tải thông tin
        private void dgvPhong_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvPhong.Rows[e.RowIndex];
            if (row.Cells["Phiếu đặt"].Value != null)
            {
                string maPhieu = row.Cells["Phiếu đặt"].Value.ToString();
                txtPhieuDangO.Text = maPhieu;
                TaiChiTietTheoPhieu(maPhieu);
            }
        }

        // Nhấn Enter tại ô "Phiếu đang ở"
        private void txtPhieuDangO_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string soPhieuDat = txtPhieuDangO.Text.Trim();
                if (!string.IsNullOrWhiteSpace(soPhieuDat))
                {
                    TaiChiTietTheoPhieu(soPhieuDat);
                }
            }
        }

        // Load Đền bù và Hóa đơn theo Mã Phiếu Đặt
        private void TaiChiTietTheoPhieu(string soPhieuDat)
        {
            try
            {
                // 1. Tải danh sách tiện nghi đền bù
                string sqlDenBu = @"
                    SELECT 
                        tn.MaTienNghi AS [Tiện nghi đền bù],
                        ct.MucDoThietHai AS [Mức độ],
                        ct.SoTien AS [Số tiền]
                    FROM PhieuDenBu pdb
                    INNER JOIN ChiTietPhieuDenBu ct ON pdb.SoPhieuDenBu = ct.SoPhieuDenBu
                    INNER JOIN TienNghi tn ON ct.MaTienNghi = tn.MaTienNghi
                    WHERE pdb.SoPhieuDat = @SoPhieuDat";

                DataTable dtDenBu = Db.Query(sqlDenBu, new SqlParameter("@SoPhieuDat", soPhieuDat));
                dgvTienNghiDenBu.DataSource = dtDenBu;
                dgvTienNghiDenBu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                // 2. Tải hóa đơn
                string sqlHD = @"
                    SELECT 
                        SoHoaDon AS [Hóa đơn],
                        SoPhieuDat AS [Phiếu đặt],
                        TienPhong AS [Tiền phòng],
                        TienDichVu AS [Tiền dịch vụ],
                        TongTien AS [Tổng tiền],
                        TrangThai AS [Trạng thái]
                    FROM HoaDon
                    WHERE SoPhieuDat = @SoPhieuDat";

                DataTable dtHD = Db.Query(sqlHD, new SqlParameter("@SoPhieuDat", soPhieuDat));
                dgvHoaDon.DataSource = dtHD;
                dgvHoaDon.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                if (dtHD.Rows.Count > 0)
                {
                    txtSoTienThanhToan.Text = Convert.ToDecimal(dtHD.Rows[0]["Tổng tiền"]).ToString("N0");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu chi tiết: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Nút Lập phiếu đền bù
        private void btnLapPhieuDenBu_Click(object sender, EventArgs e)
        {
            string soPhieuDat = txtPhieuDangO.Text.Trim();
            string soPhieuDB = txtSoPhieuDenBu.Text.Trim();

            if (string.IsNullOrWhiteSpace(soPhieuDat))
            {
                MessageBox.Show("Vui lòng chọn hoặc nhập Phiếu đang ở!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtSoTienDenBu.Text.Trim(), out decimal soTien) || soTien < 0)
            {
                MessageBox.Show("Vui lòng nhập số tiền đền bù hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Lấy số phòng từ chi tiết đặt
                string sqlGetPhong = "SELECT TOP 1 SoPhong FROM ChiTietDatPhong WHERE SoPhieuDat = @SoPhieuDat";
                object phongObj = Db.Scalar(sqlGetPhong, new SqlParameter("@SoPhieuDat", soPhieuDat));
                string soPhong = phongObj != null ? phongObj.ToString() : "P101";

                // Lưu phiếu đền bù
                string sqlPhieuDB = @"
                    IF NOT EXISTS (SELECT 1 FROM PhieuDenBu WHERE SoPhieuDenBu = @SoPhieuDB)
                    BEGIN
                        INSERT INTO PhieuDenBu (SoPhieuDenBu, SoPhieuDat, SoPhong, NgayLap, MaNV, TongTien)
                        VALUES (@SoPhieuDB, @SoPhieuDat, @SoPhong, GETDATE(), @MaNV, @TongTien)
                    END";

                Db.Execute(sqlPhieuDB,
                    new SqlParameter("@SoPhieuDB", soPhieuDB),
                    new SqlParameter("@SoPhieuDat", soPhieuDat),
                    new SqlParameter("@SoPhong", soPhong),
                    new SqlParameter("@MaNV", maNVHienTai),
                    new SqlParameter("@TongTien", soTien));

                MessageBox.Show("Lập phiếu đền bù thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiChiTietTheoPhieu(soPhieuDat);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lập phiếu đền bù: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Nút Lập hóa đơn
        private void btnLapHoaDon_Click(object sender, EventArgs e)
        {
            string soPhieuDat = txtPhieuDangO.Text.Trim();
            string soHoaDon = txtSoHoaDon.Text.Trim();

            if (string.IsNullOrWhiteSpace(soPhieuDat))
            {
                MessageBox.Show("Vui lòng chọn Phiếu đang ở!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtSoNgayTinhTien.Text.Trim(), out int soNgay) || soNgay <= 0)
            {
                soNgay = 1;
            }

            try
            {
                // 1. Tính tổng tiền phòng từ CSDL
                string sqlTienPhong = @"
                    SELECT ISNULL(SUM(p.DonGiaNgay), 0) * @SoNgay
                    FROM ChiTietDatPhong ct
                    INNER JOIN Phong p ON ct.SoPhong = p.SoPhong
                    WHERE ct.SoPhieuDat = @SoPhieuDat";

                decimal tienPhong = Convert.ToDecimal(Db.Scalar(sqlTienPhong,
                    new SqlParameter("@SoPhieuDat", soPhieuDat),
                    new SqlParameter("@SoNgay", soNgay)));

                // 2. Tính tổng tiền dịch vụ
                string sqlTienDV = @"
                    SELECT ISNULL(SUM(ct.ThanhTien), 0)
                    FROM PhieuSuDungDV p
                    INNER JOIN ChiTietPhieuSuDungDV ct ON p.SoPhieuSDDV = ct.SoPhieuSDDV
                    WHERE p.SoPhieuDat = @SoPhieuDat";

                decimal tienDichVu = Convert.ToDecimal(Db.Scalar(sqlTienDV, new SqlParameter("@SoPhieuDat", soPhieuDat)));

                decimal tongTien = tienPhong + tienDichVu;

                // 3. Thêm hoặc Cập nhật Hóa đơn
                string sqlLuuHD = @"
                    IF EXISTS (SELECT 1 FROM HoaDon WHERE SoPhieuDat = @SoPhieuDat)
                    BEGIN
                        UPDATE HoaDon 
                        SET SoNgayTinhTien = @SoNgay, TienPhong = @TienPhong, TienDichVu = @TienDichVu, TongTien = @TongTien, NgayLap = GETDATE()
                        WHERE SoPhieuDat = @SoPhieuDat
                    END
                    ELSE
                    BEGIN
                        INSERT INTO HoaDon (SoHoaDon, SoPhieuDat, NgayLap, MaNV, SoNgayTinhTien, TienPhong, TienDichVu, TongTien, TrangThai)
                        VALUES (@SoHoaDon, @SoPhieuDat, GETDATE(), @MaNV, @SoNgay, @TienPhong, @TienDichVu, @TongTien, N'Chờ thanh toán')
                    END";

                Db.Execute(sqlLuuHD,
                    new SqlParameter("@SoHoaDon", soHoaDon),
                    new SqlParameter("@SoPhieuDat", soPhieuDat),
                    new SqlParameter("@MaNV", maNVHienTai),
                    new SqlParameter("@SoNgay", soNgay),
                    new SqlParameter("@TienPhong", tienPhong),
                    new SqlParameter("@TienDichVu", tienDichVu),
                    new SqlParameter("@TongTien", tongTien));

                MessageBox.Show("Lập hóa đơn thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiChiTietTheoPhieu(soPhieuDat);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lập hóa đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Nút Thanh toán
        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            string soPhieuDat = txtPhieuDangO.Text.Trim();

            if (dgvHoaDon.Rows.Count == 0 || dgvHoaDon.DataSource == null)
            {
                MessageBox.Show("Vui lòng ấn Lập hóa đơn trước khi thanh toán!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string hinhThuc = cboHinhThuc.SelectedItem != null ? cboHinhThuc.SelectedItem.ToString() : "Tiền mặt";

                // Lấy thông tin hóa đơn
                string sqlGetHD = "SELECT SoHoaDon, TongTien FROM HoaDon WHERE SoPhieuDat = @SoPhieuDat";
                DataTable dt = Db.Query(sqlGetHD, new SqlParameter("@SoPhieuDat", soPhieuDat));

                if (dt.Rows.Count > 0)
                {
                    string soHD = dt.Rows[0]["SoHoaDon"].ToString();
                    decimal tongTien = Convert.ToDecimal(dt.Rows[0]["TongTien"]);

                    // Cập nhật trạng thái Hóa đơn
                    string sqlUpdateHD = "UPDATE HoaDon SET TrangThai = N'Đã thanh toán' WHERE SoHoaDon = @SoHoaDon";
                    Db.Execute(sqlUpdateHD, new SqlParameter("@SoHoaDon", soHD));

                    // Thêm bản ghi vào bảng ThanhToan
                    string maTT = "TT-" + DateTime.Now.ToString("ddHHmmss");
                    string sqlTT = @"
                        INSERT INTO ThanhToan (MaThanhToan, SoHoaDon, NgayThanhToan, HinhThuc, SoTien)
                        VALUES (@MaTT, @SoHD, GETDATE(), @HinhThuc, @SoTien)";

                    Db.Execute(sqlTT,
                        new SqlParameter("@MaTT", maTT),
                        new SqlParameter("@SoHD", soHD),
                        new SqlParameter("@HinhThuc", hinhThuc),
                        new SqlParameter("@SoTien", tongTien));

                    MessageBox.Show("Thanh toán thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    TaiChiTietTheoPhieu(soPhieuDat);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thanh toán: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Nút Hoàn tất trả phòng
        private void btnHoanTatTraPhong_Click(object sender, EventArgs e)
        {
            string soPhieuDat = txtPhieuDangO.Text.Trim();

            if (string.IsNullOrWhiteSpace(soPhieuDat))
            {
                MessageBox.Show("Vui lòng chọn phiếu cần trả!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // 1. Cập nhật trạng thái PhieuDatPhong -> 'Đã trả' & NgayTraThucTe
                string sqlCapNhatPhieu = @"
                    UPDATE PhieuDatPhong 
                    SET TrangThai = N'Đã trả', NgayTraThucTe = GETDATE() 
                    WHERE SoPhieuDat = @SoPhieuDat";
                Db.Execute(sqlCapNhatPhieu, new SqlParameter("@SoPhieuDat", soPhieuDat));

                // 2. Cập nhật trạng thái Phong -> 'Trống'
                string sqlCapNhatPhong = @"
                    UPDATE Phong 
                    SET TrangThai = N'Trống' 
                    WHERE SoPhong IN (SELECT SoPhong FROM ChiTietDatPhong WHERE SoPhieuDat = @SoPhieuDat)";
                Db.Execute(sqlCapNhatPhong, new SqlParameter("@SoPhieuDat", soPhieuDat));

                MessageBox.Show("Hoàn tất trả phòng thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Làm sạch giao diện
                txtPhieuDangO.Clear();
                txtSoTienDenBu.Clear();
                txtSoTienThanhToan.Clear();

                TaoMaTuDong();
                TaiTatCaPhongDangO();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hoàn tất trả phòng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}