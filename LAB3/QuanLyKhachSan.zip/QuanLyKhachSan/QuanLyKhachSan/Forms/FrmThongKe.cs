﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan
{
    public partial class FrmThongKe : Form
    {
        public FrmThongKe()
        {
            InitializeComponent();

            Load += FrmThongKe_Load;
            btnThongKe.Click += btnThongKe_Click;
        }

        private void FrmThongKe_Load(object sender, EventArgs e)
        {
            // Thiết lập mặc định khoảng thời gian rộng (bao phủ dữ liệu mẫu từ tháng 1 đến tháng 3/2026)
            dtpTuNgay.Value = new DateTime(2026, 1, 1);
            dtpDenNgay.Value = new DateTime(2026, 3, 31);

            ThucHienThongKe();
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            ThucHienThongKe();
        }

        private void ThucHienThongKe()
        {
            // Lấy từ 00:00:00 ngày từ đến 23:59:59 ngày đến
            DateTime tuNgay = dtpTuNgay.Value.Date;
            DateTime denNgay = dtpDenNgay.Value.Date.AddDays(1).AddSeconds(-1);

            try
            {
                // 1. Thống kê Số phiếu đặt
                string sqlPhieuDat = "SELECT COUNT(*) FROM PhieuDatPhong WHERE NgayLap BETWEEN @TuNgay AND @DenNgay";
                object resPhieuDat = Db.Scalar(sqlPhieuDat, new SqlParameter("@TuNgay", tuNgay), new SqlParameter("@DenNgay", denNgay));
                int soPhieuDat = resPhieuDat != null && resPhieuDat != DBNull.Value ? Convert.ToInt32(resPhieuDat) : 0;
                lblPhieuDat.Text = $"Phiếu đặt: {soPhieuDat}";

                // 2. Thống kê Số khách đang ở (Số phòng/phiếu có trạng thái 'Đang ở')
                string sqlDangO = "SELECT COUNT(*) FROM PhieuDatPhong WHERE TrangThai = N'Đang ở'";
                object resDangO = Db.Scalar(sqlDangO);
                int soDangO = resDangO != null && resDangO != DBNull.Value ? Convert.ToInt32(resDangO) : 0;
                lblDangO.Text = $"Đang ở: {soDangO}";

                // 3. Thống kê Số hóa đơn
                string sqlHoaDon = "SELECT COUNT(*) FROM HoaDon WHERE NgayLap BETWEEN @TuNgay AND @DenNgay";
                object resHoaDon = Db.Scalar(sqlHoaDon, new SqlParameter("@TuNgay", tuNgay), new SqlParameter("@DenNgay", denNgay));
                int soHoaDon = resHoaDon != null && resHoaDon != DBNull.Value ? Convert.ToInt32(resHoaDon) : 0;
                lblHoaDon.Text = $"Hóa đơn: {soHoaDon}";

                // 4. Thống kê Doanh thu Hóa đơn đã thanh toán
                string sqlDoanhThu = "SELECT ISNULL(SUM(TongTien), 0) FROM HoaDon WHERE TrangThai = N'Đã thanh toán' AND NgayLap BETWEEN @TuNgay AND @DenNgay";
                object resDoanhThu = Db.Scalar(sqlDoanhThu, new SqlParameter("@TuNgay", tuNgay), new SqlParameter("@DenNgay", denNgay));
                decimal doanhThu = resDoanhThu != null && resDoanhThu != DBNull.Value ? Convert.ToDecimal(resDoanhThu) : 0;
                lblDoanhThuHD.Text = $"Doanh thu HĐ: {doanhThu:N0} đ";

                // 5. Thống kê Tổng đền bù
                string sqlDenBu = "SELECT ISNULL(SUM(TongTien), 0) FROM PhieuDenBu WHERE NgayLap BETWEEN @TuNgay AND @DenNgay";
                object resDenBu = Db.Scalar(sqlDenBu, new SqlParameter("@TuNgay", tuNgay), new SqlParameter("@DenNgay", denNgay));
                decimal denBu = resDenBu != null && resDenBu != DBNull.Value ? Convert.ToDecimal(resDenBu) : 0;
                lblTongDenBu.Text = $"Tổng đền bù: {denBu:N0} đ";

                // 6. Nạp danh sách Dịch vụ sử dụng vào DataGridView
                string sqlDichVu = @"
                    SELECT 
                        dv.MaDV AS [Mã DV],
                        dv.TenDV AS [Tên dịch vụ],
                        SUM(ct.SoLuong) AS [Tổng số lượng],
                        SUM(ct.ThanhTien) AS [Tổng tiền]
                    FROM ChiTietPhieuSuDungDV ct
                    INNER JOIN PhieuSuDungDV p ON ct.SoPhieuSDDV = p.SoPhieuSDDV
                    INNER JOIN DichVu dv ON ct.MaDV = dv.MaDV
                    WHERE p.NgaySuDung BETWEEN @TuNgay AND @DenNgay
                    GROUP BY dv.MaDV, dv.TenDV";

                DataTable dtDV = Db.Query(sqlDichVu, new SqlParameter("@TuNgay", tuNgay), new SqlParameter("@DenNgay", denNgay));
                dgvDichVu.DataSource = dtDV;
                dgvDichVu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                if (dgvDichVu.Columns["Tổng tiền"] != null)
                {
                    dgvDichVu.Columns["Tổng tiền"].DefaultCellStyle.Format = "N0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu thống kê: " + ex.Message, "Lỗi CSDL", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}