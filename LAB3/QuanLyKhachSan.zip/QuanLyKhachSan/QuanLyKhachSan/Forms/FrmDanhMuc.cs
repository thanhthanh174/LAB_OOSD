﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan
{
    public partial class FrmDanhMuc : Form
    {
        private DataGridView dgvNhanVien;
        private DataGridView dgvLoaiTienNghi;
        private DataGridView dgvDichVu;
        private DataGridView dgvQuyDinhDenBu;

        public FrmDanhMuc()
        {
            InitializeComponent();

            this.Load += FrmDanhMuc_Load;
        }

        private void FrmDanhMuc_Load(object sender, EventArgs e)
        {
            TaoGiaoDienCacTab();
            TaiDuLieuKhuVuc();
            TaiDuLieuNhanVien();
            TaiDuLieuLoaiTienNghi();
            TaiDuLieuDichVu();
            TaiDuLieuQuyDinhDenBu();
        }

        private void LoadData()
        {
            string sql = "SELECT * FROM KhuVuc";

            try
            {
                DataTable dt = Db.Query(sql);

                // Kiểm tra xem dgvDanhMuc có tồn tại không trước khi gán
                if (dgvDanhMuc != null)
                {
                    dgvDanhMuc.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể tải dữ liệu:\n\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // =========================================================
        // TẠO BẢNG CHO CÁC TAB
        // =========================================================

        private void TaoGiaoDienCacTab()
        {
            // Kiểm tra các Control Tab trước khi add để tránh lỗi NullReferenceException
            if (tabNhanVien != null)
            {
                dgvNhanVien = TaoDataGridView();
                dgvNhanVien.Location = new Point(25, 115);
                dgvNhanVien.Size = new Size(895, 285);
                tabNhanVien.Controls.Add(dgvNhanVien);
            }

            if (tabLoaiTienNghi != null)
            {
                dgvLoaiTienNghi = TaoDataGridView();
                dgvLoaiTienNghi.Location = new Point(25, 115);
                dgvLoaiTienNghi.Size = new Size(895, 285);
                tabLoaiTienNghi.Controls.Add(dgvLoaiTienNghi);
            }

            if (tabDichVu != null)
            {
                dgvDichVu = TaoDataGridView();
                dgvDichVu.Location = new Point(25, 115);
                dgvDichVu.Size = new Size(895, 285);
                tabDichVu.Controls.Add(dgvDichVu);
            }

            if (tabQuyDinhDenBu != null)
            {
                dgvQuyDinhDenBu = TaoDataGridView();
                dgvQuyDinhDenBu.Location = new Point(25, 115);
                dgvQuyDinhDenBu.Size = new Size(895, 285);
                tabQuyDinhDenBu.Controls.Add(dgvQuyDinhDenBu);
            }
        }

        private DataGridView TaoDataGridView()
        {
            DataGridView dgv = new DataGridView();

            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.AllowUserToResizeRows = false;

            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dgv.BackgroundColor = Color.White;
            dgv.ReadOnly = true;
            dgv.MultiSelect = false;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            dgv.RowHeadersVisible = false;
            dgv.RowTemplate.Height = 35;

            dgv.AutoGenerateColumns = true;

            return dgv;
        }

        // =========================================================
        // KHU VỰC
        // =========================================================
        private void TaiDuLieuKhuVuc()
        {
            string sql = @"
                SELECT 
                    MaKhuVuc AS [Mã],
                    TenKhuVuc AS [Tên]
                FROM KhuVuc
                ORDER BY MaKhuVuc";

            DataTable dt = ThucHienTruyVan(sql);

            if (dgvDanhMuc != null)
            {
                dgvDanhMuc.AutoGenerateColumns = true;
                dgvDanhMuc.Columns.Clear();
                dgvDanhMuc.DataSource = dt;
            }
        }

        // =========================================================
        // NHÂN VIÊN
        // =========================================================

        private void TaiDuLieuNhanVien()
        {
            string sql = @"
                SELECT
                    MaNV AS [Mã],
                    HoTen AS [Họ tên],
                    VaiTro AS [Vai trò],
                    SoDienThoai AS [Điện thoại]
                FROM NhanVien
                ORDER BY MaNV";

            DataTable dt = ThucHienTruyVan(sql);

            if (dgvNhanVien != null)
            {
                dgvNhanVien.DataSource = dt;
            }
        }

        // =========================================================
        // LOẠI TIỆN NGHI
        // =========================================================

        private void TaiDuLieuLoaiTienNghi()
        {
            string sql = @"
                SELECT
                    MaLoaiTN AS [Mã],
                    TenLoaiTN AS [Tên]
                FROM LoaiTienNghi
                ORDER BY MaLoaiTN";

            DataTable dt = ThucHienTruyVan(sql);

            if (dgvLoaiTienNghi != null)
            {
                dgvLoaiTienNghi.DataSource = dt;
            }
        }

        // =========================================================
        // DỊCH VỤ
        // =========================================================

        private void TaiDuLieuDichVu()
        {
            string sql = @"
                SELECT
                    MaDV AS [Mã],
                    TenDV AS [Tên],
                    DonViTinh AS [Đơn vị],
                    DonGia AS [Đơn giá]
                FROM DichVu
                ORDER BY MaDV";

            DataTable dt = ThucHienTruyVan(sql);

            if (dgvDichVu != null)
            {
                dgvDichVu.DataSource = dt;
            }
        }

        // =========================================================
        // QUY ĐỊNH ĐỀN BÙ
        // =========================================================

        private void TaiDuLieuQuyDinhDenBu()
        {
            string sql = @"
                SELECT
                    MaQuyDinh AS [Mã],
                    MaLoaiTN AS [Mã loại],
                    MucDoThietHai AS [Mức độ thiệt hại],
                    MucDenBu AS [Mức đền bù]
                FROM QuyDinhDenBu
                ORDER BY MaQuyDinh";

            DataTable dt = ThucHienTruyVan(sql);

            if (dgvQuyDinhDenBu != null)
            {
                dgvQuyDinhDenBu.DataSource = dt;
            }
        }

        // =========================================================
        // HÀM CHẠY SELECT (ĐÃ SỬA LỖI MỞ KẾT NỐI ĐÚP)
        // =========================================================
        private DataTable ThucHienTruyVan(string sql)
        {
            try
            {
                // Sử dụng luôn hàm Db.Query vừa gọn vừa tự động đóng mở connection chuẩn
                return Db.Query(sql);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể tải dữ liệu:\n\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return new DataTable();
            }
        }

        // =========================================================
        // NÚT THÊM
        // =========================================================

        private void btnThem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Chức năng thêm dữ liệu sẽ được thực hiện ở bước tiếp theo.",
                "Danh mục",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        // =========================================================
        // ĐỔI TAB
        // =========================================================

        private void tabDanhMuc_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabDanhMuc == null || tabDanhMuc.SelectedTab == null)
                return;

            string tenTab = tabDanhMuc.SelectedTab.Text;

            if (lblTieuDeDanhMuc != null)
                lblTieuDeDanhMuc.Text = tenTab;

            if (lblDonViVaiTro != null)
            {
                if (tenTab == "Khu vực")
                {
                    lblDonViVaiTro.Text = "Sức chứa:";
                }
                else if (tenTab == "Nhân viên")
                {
                    lblDonViVaiTro.Text = "Vai trò:";
                }
                else if (tenTab == "Loại tiện nghi")
                {
                    lblDonViVaiTro.Text = "Mã loại:";
                }
                else if (tenTab == "Dịch vụ")
                {
                    lblDonViVaiTro.Text = "Đơn vị:";
                }
                else if (tenTab == "Quy định đền bù")
                {
                    lblDonViVaiTro.Text = "Mức đền bù:";
                }
            }
        }
    }
}