﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyDuLich.Data;

namespace QuanLyDuLich
{
    public partial class FormTour : Form
    {
        public FormTour()
        {
            InitializeComponent();
        }

        private void FormTour_Load(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection cn = Db.OpenConnection()) { }

                MessageBox.Show("Kết nối CSDL thành công!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                return;
            }

            LoadData();
        }

        // ===== Tải dữ liệu lên lưới =====
        private void LoadData(string keyword = "")
        {
            try
            {
                string sql = "SELECT MaTour, TenTour, SoNgay, SoDem, DonGia FROM Tour";
                DataTable dt;

                if (string.IsNullOrWhiteSpace(keyword))
                {
                    dt = Db.Query(sql + " ORDER BY MaTour");
                }
                else
                {
                    dt = Db.Query(sql + " WHERE MaTour LIKE @kw OR TenTour LIKE @kw ORDER BY MaTour",
                        new SqlParameter("@kw", "%" + keyword.Trim() + "%"));
                }

                dgvTour.DataSource = dt;

                dgvTour.Columns["MaTour"].HeaderText = "Mã tour";
                dgvTour.Columns["TenTour"].HeaderText = "Tên tour";
                dgvTour.Columns["SoNgay"].HeaderText = "Số ngày";
                dgvTour.Columns["SoDem"].HeaderText = "Số đêm";
                dgvTour.Columns["DonGia"].HeaderText = "Đơn giá (VNĐ)";
                dgvTour.Columns["DonGia"].DefaultCellStyle.Format = "N0";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không tải được dữ liệu:\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ===== Xóa trắng ô nhập =====
        private void ClearInput()
        {
            txtMaTour.Clear();
            txtTenTour.Clear();
            nudSoNgay.Value = 1;
            nudSoDem.Value = 0;
            txtDonGia.Clear();
            txtMaTour.ReadOnly = false;
            txtMaTour.Focus();
        }

        // ===== Kiểm tra dữ liệu nhập =====
        private bool ValidateInput(out decimal donGia)
        {
            donGia = 0;

            if (string.IsNullOrWhiteSpace(txtMaTour.Text))
            {
                MessageBox.Show("Vui lòng nhập mã tour!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaTour.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtTenTour.Text))
            {
                MessageBox.Show("Vui lòng nhập tên tour!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTenTour.Focus();
                return false;
            }
            if (!decimal.TryParse(txtDonGia.Text.Replace(",", "").Replace(".", ""), out donGia) || donGia <= 0)
            {
                MessageBox.Show("Đơn giá phải là số lớn hơn 0!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDonGia.Focus();
                return false;
            }
            return true;
        }

        // ===== Click dòng trên lưới -> đổ lên ô nhập =====
        private void dgvTour_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvTour.Rows[e.RowIndex];
            txtMaTour.Text = row.Cells["MaTour"].Value.ToString();
            txtTenTour.Text = row.Cells["TenTour"].Value.ToString();
            nudSoNgay.Value = Convert.ToDecimal(row.Cells["SoNgay"].Value);
            nudSoDem.Value = Convert.ToDecimal(row.Cells["SoDem"].Value);
            txtDonGia.Text = Convert.ToDecimal(row.Cells["DonGia"].Value).ToString("0");

            txtMaTour.ReadOnly = true; // không cho sửa khóa chính
        }

        // ===== Thêm =====
        private void btnThem_Click(object sender, EventArgs e)
        {
            if (!ValidateInput(out decimal donGia)) return;

            try
            {
                int count = Convert.ToInt32(Db.Scalar(
                    "SELECT COUNT(*) FROM Tour WHERE MaTour = @ma",
                    new SqlParameter("@ma", txtMaTour.Text.Trim())));

                if (count > 0)
                {
                    MessageBox.Show("Mã tour này đã tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaTour.Focus();
                    return;
                }

                Db.Execute(
                    "INSERT INTO Tour(MaTour, TenTour, SoNgay, SoDem, DonGia) VALUES (@ma, @ten, @ngay, @dem, @gia)",
                    new SqlParameter("@ma", txtMaTour.Text.Trim()),
                    new SqlParameter("@ten", txtTenTour.Text.Trim()),
                    new SqlParameter("@ngay", (int)nudSoNgay.Value),
                    new SqlParameter("@dem", (int)nudSoDem.Value),
                    new SqlParameter("@gia", donGia));

                MessageBox.Show("Thêm tour thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                ClearInput();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ===== Sửa =====
        private void btnSua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaTour.Text))
            {
                MessageBox.Show("Hãy chọn tour cần sửa trên lưới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!ValidateInput(out decimal donGia)) return;

            try
            {
                int rows = Db.Execute(
                    "UPDATE Tour SET TenTour = @ten, SoNgay = @ngay, SoDem = @dem, DonGia = @gia WHERE MaTour = @ma",
                    new SqlParameter("@ma", txtMaTour.Text.Trim()),
                    new SqlParameter("@ten", txtTenTour.Text.Trim()),
                    new SqlParameter("@ngay", (int)nudSoNgay.Value),
                    new SqlParameter("@dem", (int)nudSoDem.Value),
                    new SqlParameter("@gia", donGia));

                if (rows > 0)
                {
                    MessageBox.Show("Cập nhật thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                    ClearInput();
                }
                else
                {
                    MessageBox.Show("Không tìm thấy tour để sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ===== Xóa =====
        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaTour.Text))
            {
                MessageBox.Show("Hãy chọn tour cần xóa trên lưới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult dr = MessageBox.Show(
                "Bạn có chắc muốn xóa tour '" + txtTenTour.Text + "' không?",
                "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr != DialogResult.Yes) return;

            try
            {
                Db.Execute("DELETE FROM Tour WHERE MaTour = @ma",
                    new SqlParameter("@ma", txtMaTour.Text.Trim()));

                MessageBox.Show("Đã xóa tour!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                ClearInput();
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                // Lỗi ràng buộc khóa ngoại
                MessageBox.Show("Không thể xóa vì tour này đang được dùng ở bảng khác (chuyến, phiếu đăng ký...).",
                    "Không thể xóa", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ===== Làm mới =====
        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            ClearInput();
            txtTimKiem.Clear();
            LoadData();
        }

        // ===== Tìm kiếm =====
        private void btnTim_Click(object sender, EventArgs e)
        {
            LoadData(txtTimKiem.Text);
        }
    }
}
