﻿namespace QuanLyBenhAn
{
    partial class FormMain
    {
        private System.ComponentModel.IContainer components = null;
 
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }
 
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.lblPhuDe = new System.Windows.Forms.Label();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.btnLichHen = new System.Windows.Forms.Button();
            this.btnKhamBenh = new System.Windows.Forms.Button();
            this.btnLapToa = new System.Windows.Forms.Button();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
 
            // lblTieuDe
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 15);
            this.lblTieuDe.Size = new System.Drawing.Size(420, 35);
            this.lblTieuDe.Text = "QUẢN LÝ HỒ SƠ BỆNH ÁN";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // lblPhuDe
            this.lblPhuDe.Location = new System.Drawing.Point(0, 50);
            this.lblPhuDe.Size = new System.Drawing.Size(420, 20);
            this.lblPhuDe.Text = "Bệnh viện đa khoa quốc tế";
            this.lblPhuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
 
            // 5 nút chức năng theo luồng nghiệp vụ
            this.btnDangKy.Location = new System.Drawing.Point(40, 90);
            this.btnDangKy.Size = new System.Drawing.Size(340, 46);
            this.btnDangKy.Text = "1. Đăng ký bệnh nhân / Cấp hồ sơ";
            this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);
 
            this.btnLichHen.Location = new System.Drawing.Point(40, 146);
            this.btnLichHen.Size = new System.Drawing.Size(340, 46);
            this.btnLichHen.Text = "2. Lịch khám định kỳ";
            this.btnLichHen.Click += new System.EventHandler(this.btnLichHen_Click);
 
            this.btnKhamBenh.Location = new System.Drawing.Point(40, 202);
            this.btnKhamBenh.Size = new System.Drawing.Size(340, 46);
            this.btnKhamBenh.Text = "3. Khám bệnh / Xét nghiệm";
            this.btnKhamBenh.Click += new System.EventHandler(this.btnKhamBenh_Click);
 
            this.btnLapToa.Location = new System.Drawing.Point(40, 258);
            this.btnLapToa.Size = new System.Drawing.Size(340, 46);
            this.btnLapToa.Text = "4. Lập toa thuốc";
            this.btnLapToa.Click += new System.EventHandler(this.btnLapToa_Click);
 
            this.btnThanhToan.Location = new System.Drawing.Point(40, 314);
            this.btnThanhToan.Size = new System.Drawing.Size(340, 46);
            this.btnThanhToan.Text = "5. Thanh toán viện phí";
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
 
            this.btnThoat.Location = new System.Drawing.Point(40, 380);
            this.btnThoat.Size = new System.Drawing.Size(340, 38);
            this.btnThoat.Text = "Thoát";
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
 
            // FormMain
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 440);
            this.Controls.Add(this.lblTieuDe);
            this.Controls.Add(this.lblPhuDe);
            this.Controls.Add(this.btnDangKy);
            this.Controls.Add(this.btnLichHen);
            this.Controls.Add(this.btnKhamBenh);
            this.Controls.Add(this.btnLapToa);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.btnThoat);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý hồ sơ bệnh án";
            this.ResumeLayout(false);
        }
 
        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Label lblPhuDe;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.Button btnLichHen;
        private System.Windows.Forms.Button btnKhamBenh;
        private System.Windows.Forms.Button btnLapToa;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnThoat;
    }
}
 
