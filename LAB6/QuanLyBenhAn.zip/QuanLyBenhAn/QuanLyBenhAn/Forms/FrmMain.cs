﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QuanLyBenhAn.Data;      // namespace chứa class Db (đổi cho đúng nếu project bạn đặt khác)

namespace QuanLyBenhAn
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();

            // TEST KẾT NỐI - test xong thì xóa khối try/catch này đi
            try
            {
                MessageBox.Show("Kết nối OK: " + Db.Scalar("SELECT COUNT(*) FROM BenhNhan") + " bệnh nhân");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        // Mở form con dạng hộp thoại, đóng xong quay về menu chính
        private void MoForm(Form f)
        {
            using (f)
            {
                f.ShowDialog(this);
            }
        }

        // ---- Các form chưa làm thì để dòng báo tạm; làm xong form nào thì đổi sang dòng MoForm ----

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            // MoForm(new FormDangKy());                 // <- bỏ comment khi đã tạo FormDangKy
            MessageBox.Show("FormDangKy chưa được tạo.");
        }

        private void btnLichHen_Click(object sender, EventArgs e)
        {
            // MoForm(new FormLichHen());                // <- bỏ comment khi đã tạo FormLichHen
            MessageBox.Show("FormLichHen chưa được tạo.");
        }

        private void btnKhamBenh_Click(object sender, EventArgs e)
        {
            // MoForm(new FormKhamBenh());               // <- bỏ comment khi đã tạo FormKhamBenh
            MessageBox.Show("FormKhamBenh chưa được tạo.");
        }

        private void btnLapToa_Click(object sender, EventArgs e)
        {
            MoForm(new FormLapToa());
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            // MoForm(new FormThanhToan());              // <- bỏ comment khi đã tạo FormThanhToan
            MessageBox.Show("FormThanhToan chưa được tạo.");
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn thoát?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}